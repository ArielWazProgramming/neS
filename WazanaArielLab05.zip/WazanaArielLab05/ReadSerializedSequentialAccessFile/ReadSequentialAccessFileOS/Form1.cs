﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BankLibrary;

namespace ReadSequentialAccessFileOS
{
    [Serializable]
    public partial class ReadSequentialAccessFileForm : BankUIForm
    {
        // object for deserializing RecordSerializable in binary format
        private FileStream input; // stream for reading from a file

        private BinaryFormatter reader = new BinaryFormatter(); // object for deserializing RecordSerializable in binary format

        public ReadSequentialAccessFileForm()
        {
            InitializeComponent();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            DialogResult result; // result of OpenFileDialog
            string fileName; // name of file containing data

            using (OpenFileDialog fileChooser = new OpenFileDialog())
            {
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName; // get specified name
            }

            if (result == DialogResult.OK)
            {
                ClearTextBoxes();

                if (string.IsNullOrEmpty(fileName))
                {
                    MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    input = new FileStream(fileName, FileMode.Open, FileAccess.Read); // create FileStream to obtain read access to file

                    openButton.Enabled = false; // disable Open File button
                    nextButton.Enabled = true; // enable Next Record button
                }
            }
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            try
            {
                RecordSerializable record = (RecordSerializable)reader.Deserialize(input); // get next RecordSerializable available in file

                // store RecordSerializable values in temporary string array
                var values = new string[] {
                record.Account.ToString(),
                record.FirstName.ToString(),
                record.LastName.ToString(),
                record.Balance.ToString()
            };

                SetTextBoxValues(values); // copy string-array values to TextBox values
            }
            catch (SerializationException)
            {
                input?.Close(); // close FileStream
                openButton.Enabled = true; // enable Open File button
                nextButton.Enabled = false; // disable Next Record button

                ClearTextBoxes();
                MessageBox.Show("No more records in file", string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information); // notify user if no RecordSerializables in file
            }
        }
    }
}
