﻿using System;
using System.Windows.Forms;
using System.IO;
using BankLibrary;

namespace ReadSequentialAccessFile
{
    public partial class ReadSequentialAccessFileForm : BankUIForm
    {
        private StreamReader fileReader; // reads data from a text file
        private string fileName; // name of file containing data
        private string inputRecord; // stores the current record being read

        // parameterless constructor
        public ReadSequentialAccessFileForm()
        {
            InitializeComponent();
        }

        // invoked when user clicks the Open button
        private void openButton_Click(object sender, EventArgs e)
        {
            // create and show dialog box enabling user to open file
            DialogResult result; // result of OpenFileDialog

            using (OpenFileDialog fileChooser = new OpenFileDialog())
            {
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName; // get specified name
            }

            // ensure that user clicked "OK"
            if (result == DialogResult.OK)
            {
                ClearTextBoxes();

                // show error if user specified invalid file
                if (string.IsNullOrEmpty(fileName))
                {
                    MessageBox.Show("Invalid File Name", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    try
                    {
                        // create FileStream to obtain read access to file
                        FileStream input = new FileStream(
                            fileName, FileMode.Open, FileAccess.Read);
                        fileReader = new StreamReader(input);

                        // enable Next Record button
                        openButton.Enabled = false;
                        nextButton.Enabled = true;
                    }
                    catch (IOException)
                    {
                        MessageBox.Show("Error reading from file",
                            "File Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
            }
        }

        // invoked when user clicks Next button
        private void nextButton_Click(object sender, EventArgs e)
        {
            try
            {
                // get next record available in file
                inputRecord = fileReader.ReadLine();

                if (inputRecord != null)
                {
                    string[] inputFields = inputRecord.Split(',');

                    // copy string-array values to TextBox values
                    SetTextBoxValues(inputFields);
                }
                else
                {
                    // close StreamReader and underlying file
                    fileReader.Close();

                    // disable Next Record button
                    nextButton.Enabled = false;
                    openButton.Enabled = true;

                    ClearTextBoxes();

                    // notify user if no records in file
                    MessageBox.Show("No more records in file", string.Empty,
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (IOException)
            {
                MessageBox.Show("Error Reading from File", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
